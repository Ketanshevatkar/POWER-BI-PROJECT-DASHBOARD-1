# Disney Dashboard in Power BI

### Objective  :
Disneyland Dashboard using Microsoft Power BI by Federico Pastor | Satyajit Pattnaik

This is a use case explaining about an end to end Data Analytics project done in Power BI, which is on Disney movies.

### 🙋‍♂️Creator (Federico Pastor) : https://www.linkedin.com/in/federico-pastor/
### 🗂️ Video Link: https://www.youtube.com/watch?v=JOgK4KZBTcQ&lc=UgzP4-6QhDGqK7gFNEN4AaABAg
